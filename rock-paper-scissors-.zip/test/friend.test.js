/* Friend (pass-and-play) mode harness. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const BASE = path.join(__dirname, '..', 'assets', 'js');

class El {
  constructor(tag='div'){ this.tagName=tag.toUpperCase(); this.children=[]; this.dataset={};
    this.style={setProperty(){}}; this._text=''; this.hidden=false;
    this.classList={_s:new Set(),add:(...c)=>c.forEach(x=>this.classList._s.add(x)),
      remove:(...c)=>c.forEach(x=>this.classList._s.delete(x)),
      toggle:(c,on)=>on?this.classList._s.add(c):this.classList._s.delete(c),
      contains:(c)=>this.classList._s.has(c)}; this._l={}; }
  set className(v){this._cn=v;} get className(){return this._cn||'';}
  set textContent(v){this._text=String(v);} get textContent(){return this._text;}
  setAttribute(k,v){this['a_'+k]=v;} getAttribute(k){return this['a_'+k];}
  querySelector(){return new El();} querySelectorAll(){return [];}
  addEventListener(t,fn){(this._l[t]||=[]).push(fn);} dispatch(t,ev){(this._l[t]||[]).forEach(f=>f(ev));}
  appendChild(c){this.children.push(c);} focus(){}
  getContext(){return{setTransform(){},clearRect(){},save(){},restore(){},translate(){},rotate(){},fillRect(){},set fillStyle(v){},set globalAlpha(v){}};}
  get offsetWidth(){return 100;}
}
const registry={};
const IDS=['setup','setup-hint','setup-length','start-btn','shield','shield-btn','shield-who','result',
'result-title','result-detail','rematch-btn','change-btn','round-label','arena-heading','you-name',
'house-name','you-slot','house-slot','you-use','house-use','you-state','house-state','verdict',
'verdict-word','verdict-detail','plates','arena-prompt','advance-btn','restart-btn','score-you',
'score-house','ladder','ladder-you','ladder-house','log','log-empty','stat-matches','stat-wins',
'stat-losses','stat-ties','stat-streak','stat-best','fave','fave-name','fave-bar','reset-stats',
'sound-toggle','sound-icon','length-select','confetti'];
IDS.forEach(id=>registry[id]=new El());
registry['setup'].hidden=true; registry['shield'].hidden=true; registry['result'].hidden=true;
registry['length-select'].value='5';

const plateEls=['rock','paper','scissors'].map(g=>{const e=new El('button');e.dataset.gesture=g;
  e.closest=s=>s==='.plate'?e:null;return e;});
registry['plates'].querySelectorAll=()=>plateEls;
registry['plates'].querySelector=()=>plateEls[0];

let radioValue='friend';
const doc={readyState:'complete',getElementById:id=>registry[id]||null,
  querySelector:s=>s.includes('opponent')?{value:radioValue}:null,
  addEventListener(){},createElement:t=>new El(t),
  createElementNS:(ns,t)=>new El(t)};

const sandbox={window:null,document:doc,console,
  localStorage:{_d:{},getItem(k){return this._d[k]??null;},setItem(k,v){this._d[k]=v;}},
  performance:{now:()=>Date.now()},requestAnimationFrame:fn=>setTimeout(()=>fn(Date.now()),0),
  setTimeout:(fn,ms)=>setTimeout(fn,ms===undefined?0:ms),
  devicePixelRatio:1,innerWidth:1200,innerHeight:800,Math,Date,JSON,Object,Array,String,Number,Boolean,Error,isNaN,parseInt,parseFloat};
sandbox.window=sandbox; sandbox.globalThis=sandbox;
vm.createContext(sandbox);
for(const f of ['audio.js','house.js','app.js'])
  vm.runInContext(fs.readFileSync(path.join(BASE,f),'utf8'),sandbox,{filename:f});

let pass=0,fail=0;
const ok=(c,l)=>{c?(pass++,console.log('  PASS  '+l)):(fail++,console.log('  FAIL  '+l));};
const clickPlate=g=>registry['plates'].dispatch('click',{target:plateEls[['rock','paper','scissors'].indexOf(g)]});
const S=registry;

console.log('\n== Friend mode ==');
registry['start-btn'].dispatch('click');
ok(S['you-name'].textContent==='Player 1','player 1 labelled: '+S['you-name'].textContent);
ok(S['house-name'].textContent==='Player 2','player 2 labelled: '+S['house-name'].textContent);

clickPlate('rock');
ok(S.shield.hidden===false,'pass-and-play shield appears after player 1 chooses');
ok(S['you-slot'].dataset.gesture==='' ,'player 1 gesture stays hidden behind the shield');

registry['shield-btn'].dispatch('click');
ok(S.shield.hidden===true,'shield dismisses on "I\'m ready"');
ok(S['house-state'].textContent==='Player 2 to choose','prompt switches to player 2: '+S['house-state'].textContent);

clickPlate('paper');
setTimeout(()=>{
  // Player 1 played rock, player 2 played paper — paper covers rock, so P1 loses.
  ok(S['verdict-word'].textContent==='You lose','rock vs paper -> You lose (got "'+S['verdict-word'].textContent+'")');
  ok(S['you-slot'].dataset.gesture==='rock','player 1 slot shows rock');
  ok(S['house-slot'].dataset.gesture==='paper','player 2 slot shows paper');
  ok(S['score-house'].textContent==='1','player 2 scores');
  ok(S['score-you'].textContent==='0','player 1 has no points');

  registry['advance-btn'].dispatch('click');
  ok(S['you-state'].textContent==='Waiting','player 1 slot resets between rounds: "'+S['you-state'].textContent+'"');
  ok(S['you-slot'].dataset.gesture==='','player 1 gesture cleared for next round');

  console.log('\n---------------------------------------');
  console.log(pass+' passed, '+fail+' failed');
  process.exit(fail?1:0);
},600);
