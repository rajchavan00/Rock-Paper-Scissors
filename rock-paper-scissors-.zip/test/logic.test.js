/* Headless logic harness: stubs just enough DOM to run app.js end-to-end. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const BASE = path.join(__dirname, '..', 'assets', 'js');

/* ---------- tiny DOM ---------- */
class El {
  constructor(tag = 'div') {
    this.tagName = tag.toUpperCase();
    this.children = [];
    this.dataset = {};
    this.style = { setProperty(){}, };
    this._text = '';
    this.hidden = false;
    this.classList = {
      _s: new Set(),
      add: (...c) => c.forEach(x => this.classList._s.add(x)),
      remove: (...c) => c.forEach(x => this.classList._s.delete(x)),
      toggle: (c, on) => on ? this.classList._s.add(c) : this.classList._s.delete(c),
      contains: (c) => this.classList._s.has(c)
    };
    this._listeners = {};
  }
  set className(v) { this._cn = v; }
  get className() { return this._cn || ''; }
  set textContent(v) { this._text = String(v); }
  get textContent() { return this._text; }
  setAttribute(k, v) { this['attr_' + k] = v; }
  getAttribute(k) { return this['attr_' + k]; }
  querySelector() { return new El(); }
  querySelectorAll() { return []; }
  addEventListener(t, fn) { (this._listeners[t] ||= []).push(fn); }
  dispatch(t, ev) { (this._listeners[t] || []).forEach(fn => fn(ev)); }
  appendChild(c) { this.children.push(c); }
  focus() {}
  getContext() { return { setTransform(){}, clearRect(){}, save(){}, restore(){}, translate(){}, rotate(){}, fillRect(){}, set fillStyle(v){}, set globalAlpha(v){} }; }
  get offsetWidth() { return 100; }
}

const registry = {};
const IDS = ['setup','setup-hint','setup-length','start-btn','shield','shield-btn','shield-who',
 'result','result-title','result-detail','rematch-btn','change-btn','round-label','arena-heading',
 'you-name','house-name','you-slot','house-slot','you-use','house-use','you-state','house-state',
 'verdict','verdict-word','verdict-detail','plates','arena-prompt','advance-btn','restart-btn',
 'score-you','score-house','ladder','ladder-you','ladder-house','log','log-empty','stat-matches',
 'stat-wins','stat-losses','stat-ties','stat-streak','stat-best','fave','fave-name','fave-bar',
 'reset-stats','sound-toggle','sound-icon','length-select','confetti'];
IDS.forEach(id => { registry[id] = new El(); });

// length-select must parse
registry['length-select'].value = '5';

// Overlays start hidden in the markup, except setup which JS reveals.
registry['setup'].hidden = true;
registry['shield'].hidden = true;
registry['result'].hidden = true;

// The plates container needs real gesture buttons
const plateEls = ['rock','paper','scissors'].map(g => {
  const e = new El('button');
  e.dataset.gesture = g;
  // e.target.closest('.plate') must resolve back to the button
  e.closest = (sel) => (sel === '.plate' ? e : null);
  return e;
});
registry['plates'].querySelectorAll = () => plateEls;
registry['plates'].querySelector = () => plateEls[0];

/* Click a plate the way a user would: the event bubbles to the plates container. */
function clickPlate(g) {
  const idx = ['rock', 'paper', 'scissors'].indexOf(g);
  const target = plateEls[idx];
  registry['plates'].dispatch('click', { target: target });
}

let radioValue = 'house';
const doc = {
  readyState: 'complete',
  getElementById: (id) => registry[id] || null,
  querySelector: (sel) => {
    if (sel.includes('opponent')) return { value: radioValue };
    return null;
  },
  addEventListener() {},
  createElement: (t) => new El(t),
  createElementNS: (ns, t) => new El(t)
};

const sandbox = {
  window: null, document: doc, console,
  localStorage: {
    _d: {},
    getItem(k) { return this._d[k] ?? null; },
    setItem(k, v) { this._d[k] = v; }
  },
  performance: { now: () => Date.now() },
  requestAnimationFrame: (fn) => setTimeout(() => fn(Date.now()), 0),
  setTimeout: (fn, ms) => setTimeout(fn, ms === undefined ? 0 : ms),
  AudioContext: undefined,
  devicePixelRatio: 1,
  innerWidth: 1200, innerHeight: 800,
  Math, Date, JSON, Object, Array, String, Number, Boolean, Error, isNaN, parseInt, parseFloat
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
for (const f of ['audio.js', 'house.js', 'app.js']) {
  vm.runInContext(fs.readFileSync(path.join(BASE, f), 'utf8'), sandbox, { filename: f });
}

/* ---------- assertions ---------- */
let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; console.log('  PASS  ' + label); }
  else { fail++; console.log('  FAIL  ' + label); }
}

console.log('\n== House AI ==');
const House = sandbox.RPSHouse;
ok(typeof House === 'function', 'RPSHouse exported');
const h = new House();
const legal = new Set(['rock', 'paper', 'scissors']);
let allLegal = true, spread = new Set();
for (let i = 0; i < 3000; i++) {
  const g = h.choose(['rock','paper','scissors'][i % 3]);
  if (!legal.has(g)) allLegal = false;
  spread.add(g);
}
ok(allLegal, 'house always returns a legal gesture');
ok(spread.size === 3, 'house covers all three gestures (got ' + spread.size + ')');

const h2 = new House();
h2.difficulty = 1;
h2.history = ['rock','rock','rock','rock','rock','rock','rock','rock','rock','rock'];
const counters = new Set();
for (let i = 0; i < 200; i++) {
  const g = h2.choose('rock');
  counters.add(g);
  h2.history.push('rock');
}
ok(counters.has('paper'), 'house exploits a repeated rock with paper');

console.log('\n== Match flow (vs house) ==');
const S = registry;
ok(S.setup.hidden === false, 'setup overlay shown on load');

registry['start-btn'].dispatch('click');
ok(S.setup.hidden === true, 'setup closes on start');
ok(S['score-you'].textContent === '0' && S['score-house'].textContent === '0', 'score starts at 0-0');
ok(S['round-label'].textContent === 'Round 1 of 5', 'round label initialised: ' + S['round-label'].textContent);
ok(S['arena-heading'].textContent === 'First to 3', 'target derived from length: ' + S['arena-heading'].textContent);

console.log('\n== Verdict text ==');
// Force a known outcome by controlling the house
const realChoose = sandbox.RPSHouse.prototype.choose;
sandbox.RPSHouse.prototype.choose = function () { return 'paper'; };
clickPlate('rock');
setTimeout(() => {
  ok(S['verdict-word'].textContent === 'You lose', 'rock vs paper -> You lose (got "' + S['verdict-word'].textContent + '")');
  ok(S['score-house'].textContent === '1', 'opponent score incremented');
  ok(S['you-slot'].dataset.gesture === 'rock', 'your slot shows rock');
  ok(S['house-slot'].dataset.gesture === 'paper', 'opponent slot shows paper');

  // tie
  sandbox.RPSHouse.prototype.choose = function () { return 'scissors'; };
  registry['advance-btn'].dispatch('click');
  clickPlate('scissors');
  setTimeout(() => {
    ok(S['verdict-word'].textContent === 'Tie', 'scissors vs scissors -> Tie (got "' + S['verdict-word'].textContent + '")');
    ok(S['advance-btn'].textContent === 'Replay round', 'tie offers replay: ' + S['advance-btn'].textContent);
    // The opening loss already advanced us to round 2; a tie must NOT advance further.
    ok(S['round-label'].textContent === 'Round 2 of 5', 'tie does not advance the round counter: ' + S['round-label'].textContent);

    // win
    sandbox.RPSHouse.prototype.choose = function () { return 'paper'; };
    registry['advance-btn'].dispatch('click');
    clickPlate('scissors');
    setTimeout(() => {
      ok(S['verdict-word'].textContent === 'You win', 'scissors vs paper -> You win (got "' + S['verdict-word'].textContent + '")');
      ok(S['score-you'].textContent === '1', 'your score incremented');
      ok(S['round-label'].textContent === 'Round 2 of 5', 'still round 2 after replaying the tie: ' + S['round-label'].textContent);

      registry['advance-btn'].dispatch('click');
      ok(S['round-label'].textContent === 'Round 3 of 5', 'round advances after a decisive round: ' + S['round-label'].textContent);

      console.log('\n== Match end ==');
      let guard = 0;
      const playTo = () => {
        guard++;
        if (guard > 40) return;
        sandbox.RPSHouse.prototype.choose = function () { return 'paper'; };
        if (S['advance-btn'].hidden === false) registry['advance-btn'].dispatch('click');
        clickPlate('rock');
        setTimeout(() => {
          if (S.result.hidden === false) {
            ok(true, 'match ends and result overlay opens (you=' + S['score-you'].textContent + ' opp=' + S['score-house'].textContent + ')');
            ok(S['stat-matches'].textContent === '1', 'record: matches incremented (got ' + S['stat-matches'].textContent + ')');
            ok(S['stat-losses'].textContent === '1', 'record: loss counted (got ' + S['stat-losses'].textContent + ')');
            ok(S['result-detail'].textContent.indexOf('took') !== -1, 'result detail reads well: ' + S['result-detail'].textContent);
            sandbox.RPSHouse.prototype.choose = realChoose;
            console.log('\n---------------------------------------');
            console.log(pass + ' passed, ' + fail + ' failed');
            process.exit(fail ? 1 : 0);
          } else {
            playTo();
          }
        }, 600);
      };
      playTo();
    }, 600);
  }, 600);
}, 600);
